## Parameters
param(
    # eManager Folder
    [string]$EManagerFolder
)

## NuGet add package
cd $EManagerFolder
dotnet nuget add source https://elementlogic.myget.org/F/ewms/auth/29344e55-1c43-478c-a00e-137f1d6956ea/api/v3/index.json --name "EWS Package Feed"
dotnet nuget add source https://elementlogic.myget.org/F/shared/auth/a70646f0-dfc4-4cb9-b27f-06bff16b4eba/api/v2 --name "ElementLogic shared"
dotnet nuget add source https://elementlogic.myget.org/F/ams/auth/ead7ab75-2a4a-4664-835b-66ec283de3e0/api/v3/index.json --name "ElementLogic AMS"